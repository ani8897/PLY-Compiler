
# For maintaining new lines
line_number = 1

# printing ast
ast_file = ""

# printing cfg
cfg_file = ""
block_index = 1
temp_index = 0
block_bool = False
cfg = None